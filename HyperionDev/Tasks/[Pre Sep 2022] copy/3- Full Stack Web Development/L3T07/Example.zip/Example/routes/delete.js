module.exports = function(app) {
  const blog = require('../controllers/blog.controller.js');
  app.get('/delete', blog.deleteBlogsByAuthor);
}
