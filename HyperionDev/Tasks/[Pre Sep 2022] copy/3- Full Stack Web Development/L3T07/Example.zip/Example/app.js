var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

//HYPERION note: Remember to require Mongoose. We will be using Mongoose to connect to our Database in this 'app.js' file.
var mongoose = require('mongoose');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

/*HYPERION note: You could specify all your routing rules in this app.js file as shown in the code that has been commented out below.
It is generally considered best practice to have your routing rules for each page
in your app specified separately in the routes directory. The benefits of this approach
will become clear in later tasks. 

If you need a refresher about routing in Express, see here: https://expressjs.com/en/starter/basic-routing.html
and here: https://expressjs.com/en/guide/routing.html*/

/*var blog = require('./controllers/blog.controller.js');
app.get('/', blog.findAll);
app.get('/add', blog.create);
app.get('/delete', blog.deleteBlogsByAuthor);
app.get('/update', blog.updateByAuthor);*/

require('./routes/new.js')(app);
require('./routes/home.js')(app);
require('./routes/delete.js')(app);
require('./routes/update.js')(app); //HYPERION note: For more information about this approach to separate routes, see here:https://stackoverflow.com/questions/6059246/how-to-include-route-handlers-in-multiple-files-in-express

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

//HYPERION note: remember that you can get this uri for connecting
//to your database from Atlas>Connect from your app.
const uri = 'mongodb+srv://hyperionDB:HoARqh2lR7NcWXFo@hyperion-f78fc.mongodb.net/test?retryWrites=true';
mongoose.Promise = global.Promise;

mongoose.connect(uri, {
	useMongoClient: true
});

mongoose.connection.on('error', function() {
	console.log('Connection to Mongo established.');
    console.log('Could not connect to the database. Exiting now...');
    process.exit();
});
mongoose.connection.once('open', function() {
    console.log("Successfully connected to the database");
})


module.exports = app;
