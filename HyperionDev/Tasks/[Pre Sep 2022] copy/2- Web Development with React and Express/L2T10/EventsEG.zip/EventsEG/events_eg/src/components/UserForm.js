import React, { Component } from 'react'

export default class UserForm extends Component {
  constructor(props) {
    super(props);
    /* The height and weight are state since they change over time and can't be computed from anything. This component (as the common owner component of the state) or its parent (i.e. App) can maintain the state information since it renders the BMI value based on that state. */
    this.state = {
      height: 0,
      weight: 0
    };

    // Bind 'this' in the callback
    this.handleHeightChange = this.handleHeightChange.bind(this);
    this.handleWeightChange = this.handleWeightChange.bind(this);
    this.handleClick = this.handleClick.bind(this);
  }

  // Set the height as the value entered by the user via form
  handleHeightChange(event) {
    this.setState({
      height : event.target.value,
    })
  }

  // Set the weight as the value entered by the user via form
  handleWeightChange(event) {
    this.setState({
      weight : event.target.value,
    })
  }

  // Calculate the BMI and alert it to the user
  handleClick() {
    const bmi = this.state.weight / (this.state.height * this.state.height);
    alert("Your bmi is " + bmi.toFixed(2));
  }

  render() {
    return (
      <div>
        <form>
          <label>
            Height: 
            <input type="number" name="height" placeholder="in m..."
              onChange={ this.handleHeightChange } />
          </label>
          <br></br>
          <label>
            Weight: 
            <input type="number" name="weight" placeholder="in kg..."
              onChange={ this.handleWeightChange } />
          </label>
          <br></br>
          <input type="button" value="Calculate" 
            onClick={ this.handleClick } />
        </form>

      </div>
    )
  }
}
