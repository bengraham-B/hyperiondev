import React, { Component } from 'react'

export default class BmiOutput extends Component {
  render() {
    return (
      <div>
        
      </div>
    )
  }
}
