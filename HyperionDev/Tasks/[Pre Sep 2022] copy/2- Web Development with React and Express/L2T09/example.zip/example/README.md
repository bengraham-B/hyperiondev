In this example, we have created a number of Components (./src/Components). Some of these are functional and some are
stateful components. Read through comments in each of the files in the Components directory for more information.

The Components that we have created have been added to the App component. Open ./src/App.js and read through the comments
there to see how this has been done. 


This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).
To run this project, do the following:
1. Copy the directory called 'example' to your local machine.
2. Navigate to this directory from the command line interface. E.g. cd c:/example.
3. In the command line interface type 'npm install'
4. Now type 'npm start'. Runs the app in the development mode.
5. Open [http://localhost:3000](http://localhost:3000) to view it in the browser.
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.<br>
You will also see any lint errors in the console.

