module.exports = {
  	calculate: function(weight, height){
		var BMI = weight/(height*height);
		return BMI.toFixed(2);
  	}
};
